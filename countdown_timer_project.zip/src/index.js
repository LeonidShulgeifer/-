
import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import CountdownTimer from "./CountdownTimer";

ReactDOM.render(
  <React.StrictMode>
    <CountdownTimer />
  </React.StrictMode>,
  document.getElementById("root")
);
