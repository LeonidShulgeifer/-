
import React, { useEffect, useState } from "react";

const CountdownTimer = () => {
  const targetDate = new Date("2025-02-06");
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const difference = targetDate - now;

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((difference / 1000 / 60) % 60);
      const seconds = Math.floor((difference / 1000) % 60);

      setTimeLeft({ days, hours, minutes, seconds });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div style={{ textAlign: "center", fontFamily: "Arial, sans-serif", margin: "20px" }}>
      <h1>Countdown to Prague</h1>
      <div style={{ display: "flex", justifyContent: "center", gap: "20px" }}>
        <div>
          <span style={{ fontSize: "2rem", fontWeight: "bold" }}>{timeLeft.days}</span>
          <div>Days</div>
        </div>
        <div>
          <span style={{ fontSize: "2rem", fontWeight: "bold" }}>{timeLeft.hours}</span>
          <div>Hours</div>
        </div>
        <div>
          <span style={{ fontSize: "2rem", fontWeight: "bold" }}>{timeLeft.minutes}</span>
          <div>Minutes</div>
        </div>
        <div>
          <span style={{ fontSize: "2rem", fontWeight: "bold" }}>{timeLeft.seconds}</span>
          <div>Seconds</div>
        </div>
      </div>
    </div>
  );
};

export default CountdownTimer;
